#ifndef PROCESS84_H
#define PROCESS84_H

void process84(char str[], char ketqua[]);

#endif