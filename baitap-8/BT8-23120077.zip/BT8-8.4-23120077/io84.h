#ifndef IO84_H
#define IO84_H

void input84(char str[]);
void output84(char str[]);

#endif