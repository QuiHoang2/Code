#ifndef PROCESS82_H
#define PROCESS82_H

void kiemDuyet(char s1[], char s2[], char ketqua[]);

#endif