#ifndef IO82_H
#define IO82_H

void nhapChuoi82(char s1[], char s2[]);
void xuatChuoi82(char str[]);

#endif