#ifndef OUTPUT83_H
#define OUTPUT83_H

int arrayfind(char c, char str[], int size);
int numberarrfind(int n, int arr[], int size);
int findmax(int arr[], int size);
void process83(char str[], char ascii[], int f[]);
void output83(char ascii[], int f[]);

#endif