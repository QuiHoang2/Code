#ifndef INPUT83_H
#define INPUT83_H

void nhapChuoi83(char str[]);

#endif