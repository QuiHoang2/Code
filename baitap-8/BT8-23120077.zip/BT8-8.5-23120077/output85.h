#ifndef OUTPUT85_H
#define OUTPUT85_H

void output85(char str[], char c[]);
bool strfnd(char c, char str[]);

#endif