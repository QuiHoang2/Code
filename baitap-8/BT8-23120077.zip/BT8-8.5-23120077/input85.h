#ifndef INPUT85_H
#define INPUT85_H

void input85(char str[], char c[]);

#endif