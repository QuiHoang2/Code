#include "input85.h"
#include "output85.h"

int main(void)
{
    char str[101], c[2];
    input85(str, c);
    output85(str, c);
    return 0;
}