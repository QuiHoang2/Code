#ifndef PHANSO_H
#define PHANSO_H

struct phanso
{
    int tu {};
    int mau {};
};

void input91(phanso &ps);
void output91(phanso ps);
void rutgonps(phanso &ps);
int gcd(int a, int b);

#endif
