#include "phanso.h"

int main(void)
{
    phanso ps {};   
    input91(ps);
    rutgonps(ps);
    output91(ps);
    return 0;
}