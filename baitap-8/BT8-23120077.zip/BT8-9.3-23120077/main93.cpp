#include "tamgiac.h"

int main(void)
{
    tamgiac ABC {};
    nhapDinhTamGiac(ABC);
    tinhCanhTamGiac(ABC);
    tinhTrongTam(ABC);
    return 0;
}