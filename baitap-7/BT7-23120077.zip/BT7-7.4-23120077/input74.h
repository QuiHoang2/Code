#ifndef INPUT74_H
#define INPUT74_H

void inputmn(int &row, int &col);
void inputArray2D(int arr2D[][100], int row, int col);

#endif