#ifndef OUTPUT74_H
#define OUTPUT74_H

void check74(int arr2D[][100], int row, int col);

#endif