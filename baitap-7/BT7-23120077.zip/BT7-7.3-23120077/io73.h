#ifndef IO73_H
#define IO73_H

int inputInteger(void);
void inputArray2D(int arr2D[][100], int size);
void output73(int cheochinh, int cheophu, bool maphuong);

#endif