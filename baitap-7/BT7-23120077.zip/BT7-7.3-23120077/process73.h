#ifndef PROCESS73_H
#define PROCESS73_H

int tinhCheoChinh(int arr2D[][100], int size);
int tinhCheoPhu(int arr2D[][100], int size);
bool ktMaPhuong(int arr2D[][100], int size);
bool ktPhanTu(int arr2D[][100], int size);
bool ktHang(int arr2D[][100], int size);
bool ktCot(int arr2D[][100], int size);

#endif
