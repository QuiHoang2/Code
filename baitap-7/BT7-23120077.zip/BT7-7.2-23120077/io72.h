#ifndef IO72_H
#define IO72_H

int inputInteger(void);
void inputArray(int arr[], int size);
void output72(bool tang, bool doixung, bool cong);

#endif