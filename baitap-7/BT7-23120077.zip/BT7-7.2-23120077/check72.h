#ifndef CHECK72_H
#define CHECK72_H

bool ktTang(int arr[], int size);
bool ktDoiXung(int arr[], int size);
bool ktCapSoCong(int arr[], int size);


#endif