#ifndef I071_H
#define IO71_H

int inputInteger(void);
void inputArray(int arr[], int size);
void output71(int, int);

#endif