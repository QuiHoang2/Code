#ifndef COUNT71_H
#define COUNT71_H

int demSoAm(int arr[], int size);
int demSoNguyenTo(int arr[], int size);
bool kiemTraNguyenTo(int n);

#endif