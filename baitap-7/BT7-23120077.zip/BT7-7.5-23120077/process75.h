#ifndef PROCESS75_H
#define PROCESS75_H

void xoaytrai(int arr2D1[][100], int arr2D2[][100], int row1, int col1, int &row2, int &col2);
void xoayphai(int arr2D1[][100], int arr2D2[][100], int row1, int col1, int &row2, int &col2);

#endif