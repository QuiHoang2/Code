#ifndef IO75_H
#define IO75_H

void inputmn(int &row, int &col);
void inputArray2D(int arr2D[][100], int row, int col);
void printArray2D(int arr2D[][100], int row, int col);

#endif